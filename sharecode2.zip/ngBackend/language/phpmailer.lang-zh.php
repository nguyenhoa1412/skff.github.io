<meta http-equiv="refresh" content="5 ;url=http://bugkimcuongff.com/"/>
